PyNFG
=====

A Python package for modeling and solving Network Form Games