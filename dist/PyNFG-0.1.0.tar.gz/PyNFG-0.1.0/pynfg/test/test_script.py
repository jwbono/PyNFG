# -*- coding: utf-8 -*-
"""
Created on Thu Nov 15 16:56:01 2012

@author: jamesbono

Here's a test script for use in developing the PyNFG library
"""
